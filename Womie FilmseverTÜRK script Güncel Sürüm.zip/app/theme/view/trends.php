<?php require PATH . '/theme/view/common/header.php';?>
<div class="app-content">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo APP;?>">
                    <?php echo __('Home');?></a></li>
            <li class="breadcrumb-item active"><a href="<?php echo APP.'/trends';?>">
                    <?php echo __('En Çok İzlenenler');?></a></li>
        </ol>
    </nav>
    <div class="app-content">
        <div class="app-section">
            <div class="mb-4">
                <div class="text-24 text-white font-weight-bold">
                    <?php echo __('En Çok İzlenenler');?>
                </div>
                <div class="subtext text-12">
                    En çok izlenen film ve dizileri bu alanda bulabilir, kaçırdığınız yapımlara göz atabilirsiniz.
                </div>
            </div> 
            <?php
                    $Trends = $this->db->from(null,'
                        SELECT 
                        posts.id, 
                        posts.title_sub, 
                        posts.title, 
                        posts.hit, 
                        posts.image, 
						posts.quality,
                        posts.imdb, 
                        posts.create_year, 
                        posts.description, 
                        posts.duration,
                        categories.name,
                        countries.name as country_name,
                        posts.self, 
                        posts.type
                        FROM `posts` 
                        LEFT JOIN posts_category ON posts_category.content_id = posts.id  
                        LEFT JOIN categories ON categories.id = posts_category.category_id  
                        LEFT JOIN countries ON countries.id = posts.country  
                        WHERE posts.status = "1"
                        GROUP BY posts.id
                        ORDER BY posts.hit DESC
                        LIMIT 0,10')
                        ->all();
                        $i=1;
                    foreach ($Trends as $Trend) {
                    ?>
            <a href="<?php echo post($Trend['id'],$Trend['self'],$Trend['type']);?>" class="list-trend">
                <div class="list-media">
                    <div class="media media-cover" data-src="<?php echo UPLOAD.'/cover/'.$Trend['image'];?>">
					
                                    <?php if($Trend['quality']) { ?>
                                   <span class="Turk-tamga">
<?php

// SVG ikonlarını tanımlayan bir dizi
$qualityIcons = array(
    'TurkSes' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Seslendirme"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
    'TurkYazi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkSvY' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Ses ve yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg> <svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkYapimi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yapımı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>'
);

if ($Trend['quality']) {
    if (isset($qualityIcons[$Trend['quality']])) {
        echo $qualityIcons[$Trend['quality']];
    } else {
        echo htmlspecialchars($Trend['quality']); // Güvenlik için her zaman sanitize et
    }
} else {
    echo 'Belirtilmemiş'; // Eğer kalite belirtilmemişse
}
?>
                                   </span>
                                    <?php } ?>
					
					</div>
                </div>
                <div class="list-caption">
                    <div class="list-title">
                        <?php echo $Trend['title'];?>
                    </div>
                    <div class="list-title-sub">
                        <?php echo $Trend['title_sub'];?>
                    </div> 
                <div class="list-attr-box mb-2">
                    <?php if($Trend['name']) { ?>
                    <div class="list-attr">
                        <div class="attr">
                            <?php echo __('Category');?>
                        </div>
                        <div class="text">
                            <?php echo $Trend['name'];?>
                        </div>
                    </div>
                    <?php } ?>
                    <?php if($Trend['imdb']) { ?>
                    <div class="list-attr">
                        <div class="attr">
                            <?php echo __('IMDB');?>
                        </div>
                        <div class="text">
                            <?php echo $Trend['imdb'];?>
                        </div>
                    </div>
                    <?php } ?>
                    <?php if($Trend['country_name']) { ?>
                    <div class="list-attr">
                        <div class="attr">
                            <?php echo __('Country');?>
                        </div>
                        <div class="text">
                            <?php echo $Trend['country_name'];?>
                        </div>
                    </div>
                    <?php } ?>
                    <?php if($Trend['duration']) { ?>
                    <div class="list-attr">
                        <div class="attr">
                            <?php echo __('Duration');?>
                        </div>
                        <div class="text">
                            <?php echo $Trend['duration'].' '.__('min');?>
                        </div>
                    </div>
                    <?php } ?>
                    <?php if($Trend['create_year']) { ?>
                    <div class="list-attr">
                        <div class="attr">
                            <?php echo __('Release Date');?>
                        </div>
                        <div class="text">
                            <?php echo $Trend['create_year'];?>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                    <div class="list-description"><?php echo $Trend['description'];?></div>

                    <div class="list-view">
                        
                                <svg>
                                    <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#trend';?>" />
                                </svg>
                        <?php echo $Trend['hit'];?>
                        <span><?php echo __('kez izlendi');?></span>
                    </div>
                </div>
            </a>
            <?php $i++;} ?>
        </div>
    </div>
</div>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "WebSite",
    "url": "<?php echo APP;?>",
    "potentialAction": {
        "@type": "SearchAction",
        "target": "<?php echo APP.'/arama/';?>{search_term}",
        "query-input": "required name=q"
    }
}
</script>
<?php require PATH . '/theme/view/common/footer.php';?>