<?php require PATH . '/theme/view/common/header.php';?>
<div class="app-content">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo APP;?>"><?php echo __('Home');?></a></li>
            <li class="breadcrumb-item active"><a href="<?php echo APP.'/search/'.$Route->params->q;?>"><?php echo __('Search Results');?></a></li>
        </ol>
    </nav>
    <?php echo ads($Ads,3,'mb-3');?>
    <div class="filter-btn" data-toggle="modal" data-target="#filter">
        <svg class="icon">
            <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#filter';?>" />
        </svg>
    </div>
    <div class="d-flex">
        <div class="app-content">
            <div class="app-section">
                <div class="mb-4">
                    <div class="text-24 text-white font-weight-bold">
                        <?php echo __('Search Results');?>
                    </div>
                    <div class="subtext text-12">
                        "<?php echo urldecode($Route->params->q);?>" <?php echo __('verbal');?> <?php echo count($Movies)+count($Series)+count($Actors);?> <?php echo __('result found');?>
                    </div>
                    <div class="nav-active-border text-12 b-primary bottom mt-3">
                        <ul class="nav pt-0" id="myTab" role="tablist">
                            <li>
                                <a class="nav-link active" id="movies-tab" data-toggle="tab" href="#movies" role="tab" aria-controls="movies" aria-selected="true"><?php echo __('Movies');?></a>
                            </li>
                            <li>
                                <a class="nav-link" id="series-tab" data-toggle="tab" href="#series" role="tab" aria-controls="series" aria-selected="false"><?php echo __('Series');?></a>
                            </li>
                            <li>
                                <a class="nav-link" id="actors-tab" data-toggle="tab" href="#actors" role="tab" aria-controls="actors" aria-selected="false"><?php echo __('Actors');?></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="tab-content">
                    <!-- movies -->
                    <div class="tab-pane active" id="movies" role="tabpanel" aria-labelledby="movies-tab">
                        <div class="row row-cols-5">
                            <?php foreach ($Movies as $Movie) {?>
                            <div class="col">
                                <div class="list-movie">
                                    <a href="<?php echo post($Movie['id'],$Movie['self'],$Movie['type']);?>" class="list-media">
                                        <?php if($Movie['create_year']) { ?>
                                        <div class="list-media-attr">
                                            <div class="quality Turk-yapimyili">
                                                <?php echo $Movie['create_year'];?>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <div class="play-btn">
                                            <svg class="icon">
                                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#play';?>" />
                                            </svg>
                                        </div>
                                        <div class="media media-cover" data-src="<?php echo UPLOAD.'/cover/thumb-'.$Movie['image'];?>">
										
                                    <?php if($Movie['quality']) { ?>
                                   <span class="Turk-tamga">
<?php

// SVG ikonlarını tanımlayan bir dizi
$qualityIcons = array(
    'TurkSes' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Seslendirme"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
    'TurkYazi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkSvY' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Ses ve yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg> <svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkYapimi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yapımı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>'
);

if ($Movie['quality']) {
    if (isset($qualityIcons[$Movie['quality']])) {
        echo $qualityIcons[$Movie['quality']];
    } else {
        echo htmlspecialchars($Movie['quality']); // Güvenlik için her zaman sanitize et
    }
} else {
    echo 'Belirtilmemiş'; // Eğer kalite belirtilmemişse
}
?>
                                   </span>
                                    <?php } ?>
									
									
									
                            <div class="list-caption Turk-afis-onbilgi">
                                <span class="list-title">
                                    <?php echo $Movie['title'];?>
                                </span>
                                <span class="list-category Turk-afisturu">
                                    <?php echo $Movie['name'];?>
                                </span>
                            </div>	
										
										
										
										</div>
                                    </a>

                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                    <!-- movies -->
                    <!-- series -->
                    <div class="tab-pane" id="series" role="tabpanel" aria-labelledby="series-tab">
                        <div class="row row-cols-5">
                            <?php foreach ($Series as $Serie) {?>
                            <div class="col">
                                <div class="list-movie">
                                    <a href="<?php echo post($Serie['id'],$Serie['self'],$Serie['type']);?>" class="list-media">
                                        <?php if($Serie['create_year']) { ?>
                                        <div class="list-media-attr">
                                            <div class="quality">
                                                <?php echo $Serie['create_year'];?>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <div class="play-btn">
                                            <svg class="icon">
                                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#play';?>" />
                                            </svg>
                                        </div>
                                        <div class="media media-cover" data-src="<?php echo UPLOAD.'/cover/thumb-'.$Serie['image'];?>">

                                    <?php if($Serie['quality']) { ?>
                                   <span class="Turk-tamga">
<?php

// SVG ikonlarını tanımlayan bir dizi
$qualityIcons = array(
    'TurkSes' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Seslendirme"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
    'TurkYazi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkSvY' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Ses ve yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg> <svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkYapimi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yapımı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>'
);

if ($Serie['quality']) {
    if (isset($qualityIcons[$Serie['quality']])) {
        echo $qualityIcons[$Serie['quality']];
    } else {
        echo htmlspecialchars($Serie['quality']); // Güvenlik için her zaman sanitize et
    }
} else {
    echo 'Belirtilmemiş'; // Eğer kalite belirtilmemişse
}
?>
                                   </span>
                                    <?php } ?>
									
									
									
                            <div class="list-caption Turk-afis-onbilgi">
                                <span class="list-title">
                                    <?php echo $Serie['title'];?>
                                </span>
                                <span class="list-category Turk-afisturu">
                                    <?php echo $Serie['name'];?>
                                </span>
                            </div>											
										
										</div>
                                    </a>

                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                    <!-- series -->
                    <!-- actors -->
                    <div class="tab-pane" id="actors" role="tabpanel" aria-labelledby="actors-tab">
                        <div class="row row-cols-5">
                            <?php foreach ($Actors as $Actor) {?>
                            <div class="col">
                                <div class="list-actor">
                                    <a href="<?php echo actor($Actor['id'],$Actor['self']);?>" class="list-media" title="<?php echo $Actor['name'];?>">
                                        <div class="media" data-src="<?php echo UPLOAD.'/actor/'.$Actor['image'];?>"></div>
                                    </a>
                                    <div class="list-caption">
                                        <a href="<?php echo actor($Actor['id'],$Actor['self']);?>" class="list-title" title="<?php echo $Actor['name'];?>">
                                            <?php echo $Actor['name'];?></a>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                    <!-- actors -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php require PATH . '/theme/view/common/footer.php';?>