<?php require PATH . '/theme/view/common/assets.php';?>
<div class="d-flex align-items-center justify-content-center flex-column vh-100 noting">
    <div class="glitch" data-text="404">404</div>
    <div class="glitch glitch-p" data-text="<?php echo __('Page not found');?>"><?php echo __('Page not found');?></div>
    <a href="<?php echo APP?>"><?php echo __('Homepage Go');?></a>
</div> 