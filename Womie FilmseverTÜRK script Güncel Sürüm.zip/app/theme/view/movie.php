<?php require PATH . '/theme/view/common/header.php';?>
<div class="app-detail flex-fill">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo APP.'/movies'?>">
                    <?php echo __('Movies');?></a></li>
            <li class="breadcrumb-item active" aria-current="page">
                <?php echo $Listing['title'];?>
            </li>
        </ol>
    </nav>
    <?php require PATH . '/theme/view/common/post.header.php';?>
    <div class="detail-content">
        <div class="cover">
            <div class="media media-cover" data-src="<?php echo UPLOAD.'/cover/thumb-'.$Listing['image'];?>"></div>
        </div>
        <div class="detail-text flex-fill">
            <div class="caption">
                <div class="caption-content Turk-filmsayasi-basalan">
                    <div class="category">
                        <?php foreach ($Categories as $Category) { ?>
                        <a href="<?php echo APP.'/movies/'.$Category['self'];?>">
                            <?php echo $Category['name'];?></a>
                        <?php } ?>
                    </div>
                    <h1 class="Turk-filmsayfasi-baslik">
                        <?php echo $Listing['title'];?>
						
                        <?php if($Listing['create_year']) { ?>
                        <span class="text">(<?php echo $Listing['create_year'];?>)</span>
						<?php } ?>
						
                    </h1>
                    <h2>
                        <?php echo $Listing['title_sub']?>
                    </h2>
                </div>


                <?php if(count($Actors) > 0) { ?>
                <div class="video-attr">
                    <div class="attr Turk-filmsayasi-oyuncular">
                        <?php echo __('Oyuncular:');?>
                    </div>
                    <div class="text" data-more="" data-element="a" data-limit="6">
                        <?php foreach ($Actors as $Actor) { ?>
                        <a href="<?php echo actor($Actor['actor_id'],$Actor['self']);?>">
                            <?php echo $Actor['name'];?></a>
                        <?php } ?>
                    </div>
                </div>
                <?php } ?>
                <?php if($Listing['description']) { ?>
                <div class="video-attr">
                    <div class="text">
                        <?php echo $Listing['description'];?>
                    </div>
                </div>
                <?php } ?>
                <div class="nav-social">
                    <?php foreach ($Data['social'] as $key => $value) { ?>
                    <?php if($value) { ?>
                    <a href="<?php echo 'https://www.'.$key.'.com/'.$value;?>" target="_blank" title="<?php echo $key;?>">
                        <svg class="icon">
                            <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#'.$key;?>" />
                        </svg>
                    </a>
                    <?php } ?>
                    <?php } ?>
                </div>
                <?php if($Data['tags']) { ?>
                <div class="tags" data-more="" data-element="div" data-limit="6">
                    <?php 
                        $Tags = explode(',', $Data['tags']);
                        for ($i=0; $i <count($Tags); $i++) { 
                        ?>
                    <div>
                        <?php echo $Tags[$i];?>
                    </div>
                    <?php } ?>
                </div>
                <?php } ?>
            </div>
            <div class="action">
                <div class="video-view">
                    <div class="view-text">
                        <?php echo number_format($Listing['hit'], 0, ',', ',');?><span>
                            <?php echo __('views');?></span>
                    </div>
                </div>
                <div class="action-bar"><span style="width: <?php echo $Likes;?>%"></span></div>
                <div class="action-btns">
                    <div class="action-btn like <?php if($Vote['reaction'] == 'up') echo 'active';?>" data-id="<?php echo $Listing['id'];?>">
                        <svg>
                            <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#like';?>" />
                        </svg>
                        <span data-votes="<?php echo $Listing['likes'];?>">
                            <?php echo $Listing['likes'];?></span>
                    </div>
                    <div class="action-btn dislike <?php if($Vote['reaction'] == 'down') echo 'active';?>" data-id="<?php echo $Listing['id'];?>">
                        <svg>
                            <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#dislike';?>" />
                        </svg>
                        <span data-votes="<?php echo $Listing['dislikes'];?>">
                            <?php echo $Listing['dislikes'];?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo ads($Ads,1,'my-3');?>
    <?php if(count($Similars) > 0) { ?>
    <div class="app-section">
        <div class="app-heading">
            <div class="text">
                <?php echo __('Similar content');?>
            </div>
        </div>
        <div class="row row-cols-6 list-scrollable">
            <?php foreach ($Similars as $Similar) {?>
            <div class="col">
                <div class="list-movie">
                    <a href="<?php echo post($Similar['id'],$Similar['self'],$Similar['type']);?>" class="list-media">
                        <div class="play-btn">
                            <svg class="icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#play';?>" />
                            </svg>
                        </div>
                        <div class="media media-cover" data-src="<?php echo UPLOAD.'/cover/thumb-'.$Similar['image'];?>">
						
                                    <?php if($Similar['quality']) { ?>
                                   <span class="Turk-tamga">
<?php

// SVG ikonlarını tanımlayan bir dizi
$qualityIcons = array(
    'TurkSes' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Seslendirme"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
    'TurkYazi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkSvY' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Ses ve yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg> <svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkYapimi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yapımı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>'
);

if ($Similar['quality']) {
    if (isset($qualityIcons[$Similar['quality']])) {
        echo $qualityIcons[$Similar['quality']];
    } else {
        echo htmlspecialchars($Similar['quality']); // Güvenlik için her zaman sanitize et
    }
} else {
    echo 'Belirtilmemiş'; // Eğer kalite belirtilmemişse
}
?>
                                   </span>
                                    <?php } ?>

						</div>
                    </a>
                    <div class="list-caption">
                        <a href="<?php echo post($Similar['id'],$Similar['self'],$Similar['type']);?>" class="list-title benzer-basligim">
                            <?php echo $Similar['title'];?>
                        </a>
                        <a href="<?php echo post($Similar['id'],$Similar['self'],$Similar['type']);?>" class="list-category">
                            <?php echo $Similar['create_year'];?>
                        </a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
    <?php } ?>
    <?php if($Listing['comment'] != 1) { ?>
    <div class="row">
        <div class="col">
            <?php require PATH . '/theme/view/common/comments.php';?>
        </div>
        <?php if(ads($Ads,4,'ml-auto')) { ?>
        <div class="col-md-4">
            <?php echo ads($Ads,4,'ml-auto');?>
        </div>
        <?php } ?>
    </div>
    <?php } ?>
</div>
<?php require PATH . '/theme/view/common/schema.movie.php';?>
<?php require PATH . '/theme/view/common/footer.php';?>