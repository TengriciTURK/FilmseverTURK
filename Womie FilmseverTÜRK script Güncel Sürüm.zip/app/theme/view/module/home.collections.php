<div class="app-section">
    <div class="app-heading">
        <div class="text">
            <a href="<?php echo APP.'/collections';?>" class="FilmseverTURK-ANAbaslik">Öne Çıkan Seçkiler:</a>
        </div>
    </div>

<div class="dark-segment collection-list mb-sm">
            <div class="segment-content">
                                <div class="segment-introducing">
    <img alt="En iyi koleksiyonlar" class=" lazyloaded" src="<?php echo THEME.'/img/seckiler.jpg' ?>">
    <div>
        <h4>En iyi seçkiler</h4>
        <p>İzleyecek bir şeyler arıyorsan, seçkilere göz atabilirsin!</p>
		
		<a href="<?php echo APP.'/collections';?>" class="ui button primary">Tüm Seçkiler</a>


    </div>
</div>                <div class="collections">
        <?php    
        $Collections = $this->db->from(null,'
            SELECT 
            collections.id,
            collections.name,
            collections.self,
            collections.user_id,
            collections.color,
            users.username,
            users.avatar,
            IFNULL(p.toplam, 0) AS toplam
            FROM `collections` 
            LEFT JOIN (
              SELECT collection_id, count(collections_post.content_id) AS toplam
              FROM collections_post 
              GROUP BY collection_id
            ) p ON (collections.id = p.collection_id)
            LEFT JOIN users ON users.id = collections.user_id  
            WHERE collections.featured = "1" AND collections.privacy = "1"
            ORDER BY collections.'.$ModuleData['sorting'].'
            LIMIT 0,4')
            ->all();
        foreach ($Collections as $Collection) {
        ?>
                                            <a href="<?php echo collection($Collection['id'],$Collection['self']);?>" class="" data-navigo="">
<div class="collection-item">
        <?php
        // Koleksiyona ait son 3 içeriği çeken sorgu
        $CollectionPosts = $this->db->from(null, '
            SELECT
            posts.id,
            posts.image  -- Sadece afiş (image) yeterli
            FROM `collections_post`
            LEFT JOIN posts ON collections_post.content_id = posts.id
            WHERE collections_post.collection_id = "' . $Collection['id'] . '"
            ORDER BY collections_post.id DESC  -- En son eklenenleri al
            LIMIT 0,3')
        ->all();

        // Afişleri görüntüleme
        foreach ($CollectionPosts as $Post) {
            echo '<figure>';
            echo '<img alt="' . htmlspecialchars($Collection['name']) . '" class="lazyloaded" src="' . UPLOAD . '/cover/' . $Post['image'] . '">';
            echo '</figure>';
        }

        // Eğer 3'ten az resim varsa, eksik figürleri doldur
        $num_posts = count($CollectionPosts);
        for ($i = $num_posts; $i < 3; $i++) {
            echo '<figure>';
            echo '<img alt="' . htmlspecialchars($Collection['name']) . '" class="lazyloaded" src="/app/theme/assets/img/FilmseverTURK-afis.jpg">'; // Boş bir resim kaynağı
            echo '</figure>';
        }

        ?>
    <h3 class="title-quaternary mt-0 mb-sm"><?php echo $Collection['name'];?></h3>
    <p class="description-secondary item-stats mb-xs">
        <span class="mr-md"><?php echo $Collection['toplam'];?> içerik var</span>
        <span> </span>
    </p>
    <p class="mt-md">
        <span class="description-secondary">
		<svg height="10x" class="FilmseverTURK-seckiyiEKLEYENTamga" width="13px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 60.671 60.671" xml:space="preserve">
<g>
	<g>
		<ellipse style="fill:currentColor;" cx="30.336" cy="12.097" rx="11.997" ry="12.097"/>
		<path style="fill:currentColor;" d="M35.64,30.079H25.031c-7.021,0-12.714,5.739-12.714,12.821v17.771h36.037V42.9    C48.354,35.818,42.661,30.079,35.64,30.079z"/>
	</g>
</g>
</svg>
</span>
		        <span class="FilmseverTURK-seckiyiEKLEYEN">
            <?php echo $Collection['username'];?> </span>
    </p>
</div>
</a>

        <?php } ?>                                
                                            
                                            
                                    </div>
            </div>
        </div>



</div>