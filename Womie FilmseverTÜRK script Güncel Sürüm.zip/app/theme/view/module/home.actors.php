<div class="dark-segment sinefy-featured-genres mb-sm">
                                <article class="sfg-box">
                                  <a href="<?php echo APP;?>/category/netflix-dizileri" class="sfg-title">
                                    <h3>Netflix Dizileri</h3>
                                  </a>
                                  <div class="sfg-image">
                                    <img class=" lazyloaded" src="<?php echo THEME.'/img/netflix-dizileri.png' ?>" data-src="<?php echo THEME.'/img/netflix-dizileri.png' ?>">
                                  </div>
                                </article>
                                <article class="sfg-box">
                                  <a href="<?php echo APP;?>/category/asya-dizileri" class="sfg-title">
                                    <h3>Asya Dizileri</h3>
                                  </a>
                                  <div class="sfg-image">
                                    <img class=" lazyloaded" src="<?php echo THEME.'/img/asya-dizileri.jpg' ?>" data-src="<?php echo THEME.'/img/asya-dizileri.jpg' ?>">
                                  </div>
                                </article>
                              </div>
