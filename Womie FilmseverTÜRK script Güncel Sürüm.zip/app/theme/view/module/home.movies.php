<div class="app-section">
    <div class="app-heading">
        <div class="text">
            <a href="<?php echo APP.'/movies';?>" class="FilmseverTURK-ANAbaslik">Yeni Eklenen Filmler:</a>
        </div>
    </div>
    <div class="row row-cols-5 list-scrollable">
        <?php  
        if(!$ModuleData['sorting']) {
            $OrderBy = 'id DESC';
        }else{
            $OrderBy = $ModuleData['sorting'];
        }
        $Newests = $this->db->from(null,'
            SELECT 
            posts.id, 
            posts.title, 
            posts.title_sub, 
            posts.self, 
            posts.image, 
            posts.create_year,
            posts.quality,
            posts.imdb,
            posts.type,
            posts.created,
            categories.name
            FROM `posts` 
            LEFT JOIN posts_category ON posts_category.content_id = posts.id  
            LEFT JOIN categories ON categories.id = posts_category.category_id  
            WHERE posts.type = "movie" AND posts.status = "1"
            GROUP BY posts.id
            ORDER BY posts.'.$ModuleData['sorting'].'
            LIMIT 0,'.$HomeModule['data_limit'])
            ->all();
        foreach ($Newests as $Newest) {
        ?>
        <div class="col">
            <div class="list-movie">
                <a href="<?php echo post($Newest['id'],$Newest['self'],$Newest['type']);?>" class="list-media">
                    <?php if($Newest['create_year'] || $Newest['imdb']) { ?>
                    <div class="list-media-attr">
                        <?php if($Newest['create_year']) { ?>
                        <div class="quality Turk-yapimyili">
                            <?php echo $Newest['create_year'];?>
                        </div>
                        <?php } ?>
                        <?php if($Newest['imdb']) { ?>
                        <div class="imdb">
                            <span>
                                <?php echo $Newest['imdb'];?></span>
                            <svg x="0px" y="0px" width="36px" height="36px" viewBox="0 0 36 36">
                                <circle fill="none" stroke-width="1" cx="18" cy="18" r="16" stroke-dasharray="<?php echo round($Newest['imdb'] / 10 * 100);?> 100" stroke-dashoffset="0" transform="rotate(-90 18 18)"></circle>
                            </svg>
                        </div>
                        <?php } ?>
                    </div>
                    <?php } ?>
                    <div class="play-btn">
                        <svg class="icon">
                            <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#play';?>" />
                        </svg>
                    </div>
                    <div class="media media-cover" data-src="<?php echo UPLOAD.'/cover/'.$Newest['image'];?>">
					
					
                                    <?php if($Newest['quality']) { ?>
                                   <span class="Turk-tamga">
<?php

// SVG ikonlarını tanımlayan bir dizi
$qualityIcons = array(
    'TurkSes' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Seslendirme"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
    'TurkYazi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkSvY' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Ses ve yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg> <svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkYapimi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yapımı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>'
);

if ($Newest['quality']) {
    if (isset($qualityIcons[$Newest['quality']])) {
        echo $qualityIcons[$Newest['quality']];
    } else {
        echo htmlspecialchars($Newest['quality']); // Güvenlik için her zaman sanitize et
    }
} else {
    echo 'Belirtilmemiş'; // Eğer kalite belirtilmemişse
}
?>
                                   </span>
                                    <?php } ?>
					
					
					<div class="list-caption Turk-afis-onbilgi">
                                <span class="list-title">
                        <?php echo $Newest['title'];?>
                    </span>
                    <span class="list-category Turk-afisturu">
                        <?php echo $Newest['name'];?>
					</span>
                </div>
					
					</div>
                </a>

            </div>
        </div>
        <?php } ?>
    </div>
</div>