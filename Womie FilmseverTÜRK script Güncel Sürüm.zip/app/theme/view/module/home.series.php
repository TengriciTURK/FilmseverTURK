<div class="app-section">
    <div class="app-heading">
        <div class="text">
            <a href="<?php echo APP.'/series';?>" class="FilmseverTURK-ANAbaslik">Yeni Eklenen Diziler:</a>
        </div>
    </div>


<div class="dark-segment">
<div class="dark-segment new-tv-segment">
            <div class="segment-content">
                                                <div class="segment-introducing">
    <img alt="Yabancı Diziler" class=" lazyloaded" src="<?php echo THEME.'/img/diziler.jpg' ?>" style="">
    <div>
        <h4>Dizi Arşivi</h4>
        <p>İzlemeye değer diziler arıyorsan bu sayfa tam da sana göre!</p>
        <a href="<?php echo APP.'/series';?>" class="ui button primary" data-navigo="">Tüm Diziler</a>
    </div>
</div>                <ul class="clearfix series-list">


        <?php  
        if(!$ModuleData['sorting']) {
            $OrderBy = 'id DESC';
        }else{
            $OrderBy = $ModuleData['sorting'];
        }
        $Newests = $this->db->from(null,'
            SELECT 
            posts.id, 
            posts.title, 
            posts.title_sub, 
            posts.self, 
            posts.type, 
            posts.image, 
            posts.create_year,
            posts.quality,
            posts.imdb,
            posts.created,
            categories.name,
            categories.self as category_self
            FROM `posts` 
            LEFT JOIN posts_category ON posts_category.content_id = posts.id  
            LEFT JOIN categories ON categories.id = posts_category.category_id  
            WHERE posts.type = "serie" AND posts.status = "1"
            GROUP BY posts_category.content_id
            ORDER BY posts.'.$ModuleData['sorting'].'
            LIMIT 0,6') // Sabit 6 olarak değiştirildi
            ->all();
        foreach ($Newests as $Newest) {
        ?>


                                            <li class="segment-poster ">				
    <div class="poster poster-md">
        <div class="poster-media">
            <a href="<?php echo post($Newest['id'],$Newest['self'],$Newest['type']);?>" title="<?php echo $Newest['title'];?> izle" data-navigo="">
                <img alt="<?php echo $Newest['title'];?> izle" class=" lazyloaded" src="<?php echo UPLOAD.'/cover/large-cover-'.$Newest['image'];?>">

                <span class="poster-ses">
                                    <?php if($Newest['quality']) { ?>

<?php

// SVG ikonlarını tanımlayan bir dizi
$qualityIcons = array(
    'TurkSes' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Seslendirme"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
    'TurkYazi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkSvY' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Ses ve yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg> <svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkYapimi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yapımı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>'
);

if ($Newest['quality']) {
    if (isset($qualityIcons[$Newest['quality']])) {
        echo $qualityIcons[$Newest['quality']];
    } else {
        echo htmlspecialchars($Newest['quality']); // Güvenlik için her zaman sanitize et
    }
} else {
    echo 'Belirtilmemiş'; // Eğer kalite belirtilmemişse
}
?>

                                    <?php } ?>
                </span>
            </a>
        </div>
        <div class="poster-subject">
            <a href="<?php echo post($Newest['id'],$Newest['self'],$Newest['type']);?>" title="<?php echo $Newest['title'];?> izle" data-navigo="">
            <h4><?php echo $Newest['title'];?></h4>
            <p class="description-quaternary truncate"> <?php echo $Newest['name'];?>
			</p>
            </a>
        </div>
    </div>
</li>     
<?php } ?>
                                                                                                                                                                                                                                                           </ul>
            </div>
        </div>
</div>



</div>  