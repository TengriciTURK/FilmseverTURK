<?php require PATH . '/theme/view/common/assets.php'; ?>
<?php echo ads($Ads,5,'ads-skin');?>
<div class="container">
    <div class="app">
        <div class="app-header">
            <div class="navbar navbar-expand-lg">
                <div class="menu d-md-none d-block" data-toggle="modal" data-target="#aside">
                    <svg class="icon">
                        <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#bars';?>" />
                    </svg>
                </div>
                <div class="app-navbar">
<a href="<?php echo APP;?>" class="navbar-brand FilmseverTURK-TamgaSekli">
<svg fill="#ebbd17" height="24x" width="24px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 191.255 191.255" xml:space="preserve" style="width: 22px !important;margin-right: 10px;">
<path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833  s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406  V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723  c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883  C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364  c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z" style="fill: #ebbd17;"></path>
</svg><?php echo get($Settings,'data.company','general');?>
                    </a>
                </div>
                <div class="search-btn d-md-none d-block">
                    <svg class="icon">
                        <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#search';?>" />
                    </svg>
                </div>
                <form class="header-search input-group d-md-block d-none" method="post" action="<?php echo APP.'/search';?>" id="navbarToggler">
                    <input type="hidden" name="_ACTION" value="search">
                    <input type="hidden" name="_TOKEN" value="<?php echo $Token;?>">
                    <div class="typeahead__container app-search">
                        <div class="typeahead__field">
                            <div class="typeahead__query">
                                <label for="search-input" class="btn px-0 mb-0" aria-label="<?php echo __('Search');?>">
                                    <svg class="icon">
                                        <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#search';?>" />
                                    </svg>
                                </label>
                                <input class="video-search form-control" name="q" type="text" id="search-input" placeholder="<?php echo __('Search');?> .." autocomplete="off">
                                <button type="button" class="btn close-btn d-md-none d-block px-0" aria-label="<?php echo __('Close');?>">
                                    <svg class="icon">
                                        <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#close';?>" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
                <ul class="navbar-nav navbar-user ml-auto align-items-center text-nowrap">
                    <?php if ($AuthUser['id']) { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP.'/profile/'.$AuthUser['username'].'#collections';?>" aria-label="<?php echo __('Collections');?>">
                            <svg class="icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#bookmark';?>" />
                            </svg>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle notification-btn" href="#" role="button" id="dropdown-notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" aria-label="<?php echo __('Notifications');?>">
                            <svg class="icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#bell';?>" />
                            </svg>
                        </a>
                        <div class="dropdown-menu dropdown-notification dropdown-menu-right" aria-labelledby="dropdown-notification">
                            <div class="notifications">
                                <div class="text-center">
                                    <?php echo __('Empty Notifications');?>
                                </div>
                            </div>
                            <a href="<?php echo APP.'/notifications';?>" class="all text-center">
                                <?php echo __('All');?></a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link nav-profile dropdown-toggle pr-md-0" href="#" role="button" id="dropdown-profile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" aria-label="Profile">
                            <div>
                                <?php echo gravatar($AuthUser['id'],$AuthUser['avatar'],$AuthUser['name'],'avatar avatar-sm');?>
                            </div>
                            <div class="profile-text">
                                <div class="profile-head">
                                    <?php echo __('Hello');?>,</div>
                                <div class="text-nowrap">
                                    <?php echo $AuthUser['name'];?>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-profile" aria-labelledby="Dropdown Profile">
                            <?php if($AuthUser['account_type'] == 'admin') { ?>
                            <a class="dropdown-item" href="<?php echo APP.'/admin';?>">
                                <?php echo __('Admin panel');?></a>
                            <div class="dropdown-divider"></div>
                            <?php } ?>
                            <a class="dropdown-item" href="<?php echo APP.'/profile/'.$AuthUser['username'];?>">
                                <?php echo __('Profile');?></a>
                            <a class="dropdown-item d-flex" href="<?php echo APP.'/profile/'.$AuthUser['username'].'#collections';?>">
                                <?php echo __('Collections');?></a>
                            <a class="dropdown-item" href="<?php echo APP.'/notifications';?>">
                                <?php echo __('Notifications');?></a>
                            <a class="dropdown-item" href="<?php echo APP.'/settings';?>">
                                <?php echo __('Settings');?></a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo APP.'/logout';?>">
                                <?php echo __('Logout');?></a>
                        </div>
                    </li>
                    <?php } else { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP.'/register';?>" aria-label="<?php echo __('Register');?>">
                            <?php echo __('Kayıt Ol');?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP.'/login';?>" aria-label="<?php echo __('Login');?>">
                            <?php echo __('Giriş Yap');?>
                        </a>
                    </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <div class="app-wrapper">
            <div class="app-aside nav-aside" id="aside">
                <button class="modal-close d-md-none d-block" data-dismiss="modal">
                    <svg class="icon">
                        <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#close';?>" />
                    </svg>
                </button>
                <ul class="nav mb-3 nav-user d-md-none d-block">
                    <?php if ($AuthUser['id']) { ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link nav-profile dropdown-toggle" href="#" role="button" id="dropdown-profile-mobile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" aria-labelledby="Profile Mobile">
                            <?php echo gravatar($AuthUser['id'],$AuthUser['avatar'],$AuthUser['name'],'avatar avatar-sm');?>
                            <div class="profile-text">
                                <div class="profile-head">
                                    <?php echo __('Hello');?>,</div>
                                <div class="text-nowrap">
                                    <?php echo $AuthUser['name'];?>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-profile" aria-labelledby="Dropdown Profile Mobile">
                            <?php if($AuthUser['account_type'] == 'admin') { ?>
                            <a class="dropdown-item" href="<?php echo APP.'/admin';?>">
                                <?php echo __('Admin panel');?></a>
                            <div class="dropdown-divider"></div>
                            <?php } ?>
                            <a class="dropdown-item" href="<?php echo APP.'/profile/'.$AuthUser['username'];?>">
                                <?php echo __('Profile');?></a>
                            <a class="dropdown-item d-flex" href="<?php echo APP.'/profile/'.$AuthUser['username'].'#collections';?>">
                                <?php echo __('Collections');?></a>
                            <a class="dropdown-item" href="<?php echo APP.'/notifications';?>">
                                <?php echo __('Notifications');?></a>
                            <a class="dropdown-item" href="<?php echo APP.'/settings';?>">
                                <?php echo __('Settings');?></a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo APP.'/logout';?>">
                                <?php echo __('Logout');?></a>
                        </div>
                    </li>
                    <?php } else { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP.'/register';?>" aria-label="<?php echo __('Register');?>">
                            <?php echo __('Kayıt Ol');?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP.'/login';?>" aria-label="<?php echo __('Login');?>">
                            <?php echo __('Giriş Yap');?>
                        </a>
                    </li>
                    <?php } ?>
                </ul>
                <ul class="nav">
                    <li <?php if(empty($Config['nav'])) echo 'class="active"' ;?>>
                        <a href="<?php echo APP.'/';?>">
                            <?php if(get($Settings,'data.menuicon','theme') == 1) { ?>
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#house';?>" />
                            </svg>
                            <?php } ?>
							<svg id="home" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="Turk-soltaraf-tamga Turk-soltaraf-AnasayfaTamga"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                            <?php echo __('Home');?></a>
                    </li>
                    <li <?php if($Config['nav']=='discovery' ) echo 'class="active"' ;?>>
                        <a href="<?php echo APP.'/discovery';?>">
                            <?php if(get($Settings,'data.menuicon','theme') == 1) { ?>
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#discovery';?>" />
                            </svg>
                            <?php } ?>
                            <svg id="explore" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="Turk-soltaraf-tamga" style="width: 24px;height: 24px;padding-right: 5px;"><circle cx="12" cy="12" r="10"></circle><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"></polygon></svg>
							<?php echo __('Discovery');?></a>
                    </li>

                    <?php if(get($Settings,'data.movie','block') == 1) { ?>
                    <li <?php if($Config['nav'] == 'movies' ) echo 'class="active"' ;?>>
                        <a href="<?php echo APP.'/movies';?>">
                            <?php if(get($Settings,'data.menuicon','theme') == 1) { ?>
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#film';?>" />
                            </svg>
                            <?php } ?>
							<svg xmlns="http://www.w3.org/2000/svg" class="Turk-soltaraf-tamga" viewBox="0 0 24 24" id="Layer_1" data-name="Layer 1"><defs><style>.cls-1{fill:none;stroke:currentColor;stroke-miterlimit:10;stroke-width:1.91px;}</style></defs><circle class="cls-1" cx="12.02" cy="12" r="10.52"/><circle class="cls-1" cx="12.02" cy="6.26" r="1.91"/><circle class="cls-1" cx="12.02" cy="17.74" r="1.91"/><circle class="cls-1" cx="12.02" cy="17.74" r="1.91"/><circle class="cls-1" cx="6.28" cy="12" r="1.91"/><circle class="cls-1" cx="17.76" cy="12" r="1.91"/><circle class="cls-1" cx="17.76" cy="12" r="1.91"/><line class="cls-1" x1="23.5" y1="22.52" x2="12.02" y2="22.52"/><line class="cls-1" x1="11.07" y1="12" x2="12.98" y2="12"/></svg>
                            <?php echo __('Movies');?></a>
                    </li>
                    <?php } ?>
                    <?php if(get($Settings,'data.serie','block') == 1) { ?>
                    <li <?php if($Config['nav'] == 'series') echo 'class="active"' ;?>>
                        <a href="<?php echo APP.'/series';?>" class="Turk-soltaraf-DiziBaslik">
                            <?php if(get($Settings,'data.menuicon','theme') == 1) { ?>
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#tv';?>" />
                            </svg>
                            <?php } ?>
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="Turk-soltaraf-Dizitamga" viewBox="0 0 24 24" version="1.1">
    <g xmlns="http://www.w3.org/2000/svg" id="FilmseverTURK" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Device" transform="translate(-768.000000, 0.000000)">
            <g id="tv_2_line" transform="translate(768.000000, 0.000000)">
                <path d="M24,0 L24,24 L0,24 L0,0 L24,0 Z M12.5934901,23.257841 L12.5819402,23.2595131 L12.5108777,23.2950439 L12.4918791,23.2987469 L12.4918791,23.2987469 L12.4767152,23.2950439 L12.4056548,23.2595131 C12.3958229,23.2563662 12.3870493,23.2590235 12.3821421,23.2649074 L12.3780323,23.275831 L12.360941,23.7031097 L12.3658947,23.7234994 L12.3769048,23.7357139 L12.4804777,23.8096931 L12.4953491,23.8136134 L12.4953491,23.8136134 L12.5071152,23.8096931 L12.6106902,23.7357139 L12.6232938,23.7196733 L12.6232938,23.7196733 L12.6266527,23.7031097 L12.609561,23.275831 C12.6075724,23.2657013 12.6010112,23.2592993 12.5934901,23.257841 L12.5934901,23.257841 Z M12.8583906,23.1452862 L12.8445485,23.1473072 L12.6598443,23.2396597 L12.6498822,23.2499052 L12.6498822,23.2499052 L12.6471943,23.2611114 L12.6650943,23.6906389 L12.6699349,23.7034178 L12.6699349,23.7034178 L12.678386,23.7104931 L12.8793402,23.8032389 C12.8914285,23.8068999 12.9022333,23.8029875 12.9078286,23.7952264 L12.9118235,23.7811639 L12.8776777,23.1665331 C12.8752882,23.1545897 12.8674102,23.1470016 12.8583906,23.1452862 L12.8583906,23.1452862 Z M12.1430473,23.1473072 C12.1332178,23.1423925 12.1221763,23.1452606 12.1156365,23.1525954 L12.1099173,23.1665331 L12.0757714,23.7811639 C12.0751323,23.7926639 12.0828099,23.8018602 12.0926481,23.8045676 L12.108256,23.8032389 L12.3092106,23.7104931 L12.3186497,23.7024347 L12.3186497,23.7024347 L12.3225043,23.6906389 L12.340401,23.2611114 L12.337245,23.2485176 L12.337245,23.2485176 L12.3277531,23.2396597 L12.1430473,23.1473072 Z" id="MingCute" fill-rule="nonzero">

</path>
                <path d="M16.9497,4.00691 C17.3402,3.61639 17.3402,2.98322 16.9497,2.5927 C16.5591,2.20217 15.926,2.20217 15.5355,2.5927 L11.6464,6.48179 C11.4511,6.67705 11.1345,6.67705 10.9393,6.48179 L8.46439,4.00691 C8.07387,3.61639 7.4407,3.61639 7.05018,4.00691 C6.65965,4.39744 6.65965,5.0306 7.05018,5.42113 L8.46439,6.83534 C8.52134,6.89229 8.57958,6.94716 8.63902,6.99996 L5,6.99996 C3.89543,6.99996 3,7.89539 3,8.99996 L3,19 C3,20.1045 3.89543,21 5,21 L19,21 C20.1046,21 21,20.1045 21,19 L21,8.99996 C21,7.89539 20.1046,6.99996 19,6.99996 L13.9466,6.99996 C14.0061,6.94716 14.0643,6.89229 14.1212,6.83534 L16.9497,4.00691 Z M5,8.99996 L19,8.99996 L19,19 L5,19 L5,8.99996 Z" id="FilmseverTURK" fill="currentColor">

</path>
            </g>
        </g>
    </g>
</svg>
                            <?php echo __('Diziler');?></a>
                    </li>
                    <?php } ?>
                    <?php if(get($Settings,'data.actors','block') == 1) { ?>
                    <li <?php if($Config['nav'] =='actors' ) echo 'class="active"' ;?>>
                        <a href="<?php echo APP.'/actors';?>">
                            <?php if(get($Settings,'data.menuicon','theme') == 1) { ?>
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#actors';?>" />
                            </svg>
                            <?php } ?>
							<svg viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="Turk-soltaraf-tamga"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                            <?php echo __('Actors');?>
                        </a>
                    </li>
                    <?php } ?>

					
                    <?php if(get($Settings,'data.categories','block') == 1) { ?>
                    <li <?php if($Config['nav'] =='categories' ) echo 'class="active"' ;?>>
                        <a href="<?php echo APP.'/categories';?>">
                            <?php if(get($Settings,'data.menuicon','theme') == 1) { ?>
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#categories';?>" />
                            </svg>
                            <?php } ?>
							<svg xmlns="http://www.w3.org/2000/svg" class="Turk-soltaraf-tamga" viewBox="0 0 24 24" fill="none">
<path d="M7.24 2H5.34C3.15 2 2 3.15 2 5.33V7.23C2 9.41 3.15 10.56 5.33 10.56H7.23C9.41 10.56 10.56 9.41 10.56 7.23V5.33C10.57 3.15 9.42 2 7.24 2Z" fill="currentColor"/>
<path d="M18.6695 2H16.7695C14.5895 2 13.4395 3.15 13.4395 5.33V7.23C13.4395 9.41 14.5895 10.56 16.7695 10.56H18.6695C20.8495 10.56 21.9995 9.41 21.9995 7.23V5.33C21.9995 3.15 20.8495 2 18.6695 2Z" fill="currentColor"/>
<path d="M18.6695 13.4297H16.7695C14.5895 13.4297 13.4395 14.5797 13.4395 16.7597V18.6597C13.4395 20.8397 14.5895 21.9897 16.7695 21.9897H18.6695C20.8495 21.9897 21.9995 20.8397 21.9995 18.6597V16.7597C21.9995 14.5797 20.8495 13.4297 18.6695 13.4297Z" fill="currentColor"/>
<path d="M7.24 13.4297H5.34C3.15 13.4297 2 14.5797 2 16.7597V18.6597C2 20.8497 3.15 21.9997 5.33 21.9997H7.23C9.41 21.9997 10.56 20.8497 10.56 18.6697V16.7697C10.57 14.5797 9.42 13.4297 7.24 13.4297Z" fill="currentColor"/>
</svg>
                            <?php echo __('Categories');?></a>
                    </li>
                    <?php } ?>
					
                    <?php if(get($Settings,'data.trends','block') == 1) { ?>
                    <li <?php if($Config['nav'] == 'trends' ) echo 'class="active"' ;?>>
                        <a href="<?php echo APP.'/trends';?>">
                            <?php if(get($Settings,'data.menuicon','theme') == 1) { ?>
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#trend';?>" />
                            </svg>
                            <?php } ?>
							<svg xmlns="http://www.w3.org/2000/svg" class="Turk-soltaraf-tamga" viewBox="0 0 256 256" id="explore" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M240.00244,56.00513V120a8,8,0,0,1-16,0V75.314l-82.34277,82.34278a8.00122,8.00122,0,0,1-11.31446,0L96.00244,123.314,29.65967,189.65674a8.00018,8.00018,0,0,1-11.31446-11.31348l72-72a8.00122,8.00122,0,0,1,11.31446,0L136.00244,140.686,212.68848,64h-44.686a8,8,0,0,1,0-16h64c.02979,0,.0586.00415.08838.00439.2334.00269.46631.01246.69824.0354.12891.01246.25391.03638.38086.05494.13135.01928.26319.03418.39356.06006.14013.02783.27685.06591.41455.10107.11474.0293.23047.0542.34424.08862.13427.04053.26367.09058.395.13794.11523.04151.231.07935.34472.12647.1211.05.23682.10864.35449.16455.11914.05615.23926.10888.356.17138.11133.05957.21729.12745.3252.19214.11621.06934.23388.135.34668.2107.11718.07812.227.16552.33984.24951.09668.07226.1958.13965.28955.21679.18652.15284.36426.31519.53565.48389.01611.01611.03417.0293.05029.04541.02051.02051.0376.04321.05762.064.16357.167.32177.33935.47021.52026.083.10059.15527.20654.23193.31006.07862.10571.16065.20874.23438.31836.08057.1206.15088.24585.22461.36987.05957.1001.12207.19751.17724.30029.06788.126.125.25538.18506.384.05078.1084.10547.2146.15137.32568.05127.12476.09326.252.13867.37842.04248.11987.08887.238.126.36059.03857.12769.06738.25757.09912.38672.03125.124.06592.2461.09131.37256.02978.15088.04785.30322.06933.45532.01465.10645.03516.21094.0459.31861Q240.002,55.60571,240.00244,56.00513Z"></path>
</svg>
                            <?php echo __('Çok İzlenenler');?></a>
                    </li>
                    <?php } ?>
					
                    <li class="nav-header">
                        <?php echo __('Üyelere Özel:');?>
                    </li>

                    <?php if(get($Settings,'data.discussions','block') == 1) { ?>
                    <li <?php if($Config['nav'] =='discussions' ) echo 'class="active"' ;?>>
                        <a href="<?php echo APP.'/discussions';?>">
                            <?php if(get($Settings,'data.menuicon','theme') == 1) { ?>
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#discussion';?>" />
                            </svg>
                            <?php } ?>
							<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="Turk-soltaraf-tamga" viewBox="0 0 16 16" id="forum-16px">
  <path id="Path_101" data-name="Path 101" d="M-7.5,16a.48.48,0,0,1-.158-.026L-10,15.193A5.971,5.971,0,0,1-13,16a6.006,6.006,0,0,1-6-6,6.006,6.006,0,0,1,6-6,6.006,6.006,0,0,1,6,6,5.976,5.976,0,0,1-.807,3l.782,2.345a.5.5,0,0,1-.121.512A.5.5,0,0,1-7.5,16ZM-13,5a5.006,5.006,0,0,0-5,5,5.006,5.006,0,0,0,5,5,4.984,4.984,0,0,0,2.668-.777.5.5,0,0,1,.426-.052l1.616.538-.539-1.615a.5.5,0,0,1,.052-.426A4.982,4.982,0,0,0-8,10,5.006,5.006,0,0,0-13,5Zm-9.342,7.974,3-1a.5.5,0,0,0,.317-.632.5.5,0,0,0-.633-.316l-2.051.683L-20.94,9.4a.5.5,0,0,0-.073-.454,4.96,4.96,0,0,1,.478-6.485A4.966,4.966,0,0,1-17,1a4.966,4.966,0,0,1,3.535,1.464.5.5,0,0,0,.707,0,.5.5,0,0,0,0-.707A5.959,5.959,0,0,0-17,0a5.959,5.959,0,0,0-4.242,1.757,5.948,5.948,0,0,0-.727,7.569l-1.006,3.016a.5.5,0,0,0,.121.512A.5.5,0,0,0-22.5,13,.48.48,0,0,0-22.342,12.974Z" transform="translate(23)"/>
</svg>
                            <?php echo __('Discussions');?></a>
                    </li>
                    <?php } ?>
                    <?php if(get($Settings,'data.collections','block') == 1) { ?>
                    <li <?php if($Config['nav'] == 'collections' ) echo 'class="active"' ;?>>
                        <a href="<?php echo APP.'/collections';?>">
                            <?php if(get($Settings,'data.menuicon','theme') == 1) { ?>
                            <svg class="nav-icon">
                                <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#collections';?>" />
                            </svg>
                            <?php } ?>
							<svg xmlns="http://www.w3.org/2000/svg" class="Turk-soltaraf-tamga" viewBox="0 0 24 24" fill="none"><path xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" d="M8 3a1 1 0 0 0 1 1h5.795c1.114 0 1.519.116 1.926.334.407.218.727.538.945.945.218.407.334.811.334 1.926V17a1 1 0 0 0 2 0V7.128c0-1.783-.186-2.43-.534-3.082a3.635 3.635 0 0 0-1.512-1.512C17.302 2.186 16.655 2 14.872 2H9a1 1 0 0 0-1 1zm4.795 3h-5.59c-1.115 0-1.519.116-1.926.334a2.272 2.272 0 0 0-.945.945C4.116 7.686 4 8.09 4 9.205V20.92a1 1 0 0 0 1.624.781L10 18.204l4.376 3.497a1 1 0 0 0 1.624-.78V9.204c0-1.115-.116-1.519-.334-1.926a2.272 2.272 0 0 0-.945-.945C14.314 6.116 13.91 6 12.795 6z" fill="currentColor"/></svg>
                            <?php echo __('Üyelerin Seçtikleri');?></a>
                    </li>
                    <?php } ?>
                </ul>
                    <?php if(get($Settings,'data.trends','block') == 1) { ?>
                <ul class="nav-trend d-none d-lg-block">
                    <li class="nav-header"><?php echo __('Çok İzlenenler:');?></li>
                    <?php 

                    $Trends = $this->db->from(null,'
                        SELECT 
                        posts.id, 
                        posts.title, 
                        posts.hit, 
                        posts.self, 
                        posts.type 
                        FROM `posts` 
                        WHERE posts.status = "1"
                        ORDER BY posts.hit DESC
                        LIMIT 0,10')
                        ->all();
						
					    $i = 1; // Sayaç değişkeni
						
                    foreach ($Trends as $Trend) { 
                    ?>
                    <li>
					<div class="FilmseverTURK-Sayiliklar">#<?php echo $i; ?></div>
                        <div>
                        <a href="<?php echo post($Trend['id'],$Trend['self'],$Trend['type']);?>" class="nav-content">
                            <div><?php echo $Trend['title'];?></div>
                            <div class="view">
                                <svg>
                                    <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#trend';?>" />
                                </svg>
                                <div><?php echo $Trend['hit'].' '.__('views');?></div>
                            </div>
                        </a>
						</div>
                    </li>
                    <?php 
                        $i++; // Sayacı arttır
                    } ?>
                </ul>
                    <?php } ?>
            </div>
            <div class="app-container flex-fill">
                <div class="container">