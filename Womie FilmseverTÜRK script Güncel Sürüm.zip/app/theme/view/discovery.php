<?php require PATH . '/theme/view/common/header.php';?>
<div class="app-content">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo APP;?>">
                    <?php echo __('Home');?></a></li>
            <li class="breadcrumb-item active"><a href="<?php echo APP.'/discovery';?>">
                    <?php echo __('Discovery');?></a>
            </li>
        </ol>
    </nav>
    <?php echo ads($Ads,3,'mb-3');?>
    <div class="filter-btn" data-toggle="modal" data-target="#filter">
        <svg class="icon">
            <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#filter';?>" />
        </svg>
    </div>
    <div class="d-flex">
        <div class="app-content">
            <div class="app-toolbar">
                <div class="mb-3">
                    <div class="text-24 text-white font-weight-bold">
                        <?php echo __('Discovery');?>
                    </div>
                </div>
                <?php 
                $FilterType = 1;
                require PATH . '/theme/view/common/filter.header.php';
                ?>
                <div class="app-section">
                    <!-- movies -->
                    <div class="row row-cols-2 row-cols-md-5">
                        <?php foreach ($Listings as $Listing) {?>
                        <div class="col">
                            <div class="list-movie">
                                <a href="<?php echo post($Listing['id'],$Listing['self'],$Listing['type']);?>" class="list-media">
                                    <?php if($Listing['create_year'] || $Listing['imdb']) { ?>
                                    <div class="list-media-attr">
                                        <?php if($Listing['create_year']) { ?>
                                        <div class="quality Turk-yapimyili">
                                            <?php echo $Listing['create_year'];?>
                                        </div>
                                        <?php } ?>
                                        <?php if($Listing['imdb']) { ?>
                                        <div class="imdb">
                                            <span>
                                                <?php echo $Listing['imdb'];?></span>
                                            <svg x="0px" y="0px" width="36px" height="36px" viewBox="0 0 36 36">
                                                <circle fill="none" stroke-width="1" cx="18" cy="18" r="16" stroke-dasharray="<?php echo round($Listing['imdb'] / 10 * 100);?> 100" stroke-dashoffset="0" transform="rotate(-90 18 18)"></circle>
                                            </svg>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    <?php } ?>
                                    <div class="play-btn">
                                        <svg class="icon">
                                            <use xlink:href="<?php echo ASSETS.'/img/sprite.svg#play';?>" />
                                        </svg>
                                    </div>
                                    <div class="media media-cover" data-src="<?php echo UPLOAD.'/cover/thumb-'.$Listing['image'];?>">
									
                                    <?php if($Listing['quality']) { ?>
                                   <span class="Turk-tamga">
<?php

// SVG ikonlarını tanımlayan bir dizi
$qualityIcons = array(
    'TurkSes' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Seslendirme"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
    'TurkYazi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkSvY' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Ses ve yazı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg> <svg xmlns="http://www.w3.org/2000/svg" class="Turk-yazi" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#07a7ef" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>',
	'TurkYapimi' => '<span class="TurkdilTamgalari" data-placement="left" data-toggle="tooltip" title="Türk Yapımı"><svg xmlns="http://www.w3.org/2000/svg" class="Turk-seslendirme" viewBox="0 0 16 12" enable-background="new 0 0 16 12"><switch><g><path fill="#e62126" d="m0 0h16v12h-16z"/><g><path fill="#fff" d="m7.856 7.565c-.524.835-1.457 1.389-2.518 1.389-1.638 0-2.966-1.322-2.966-2.953 0-1.632 1.328-2.954 2.966-2.954 1.061 0 1.993.554 2.518 1.389-.413-.427-.992-.693-1.634-.693-1.252 0-2.268 1.01-2.268 2.258 0 1.248 1.016 2.258 2.268 2.258.642.001 1.221-.266 1.634-.693"/><path fill="#fff" d="m7.978 4.966h1.913v1.912h-1.913z" transform="matrix(.70711-.70711.70711.70711-1.57 8.05)"/></g></g></switch></svg></span>'
);

if ($Listing['quality']) {
    if (isset($qualityIcons[$Listing['quality']])) {
        echo $qualityIcons[$Listing['quality']];
    } else {
        echo htmlspecialchars($Listing['quality']); // Güvenlik için her zaman sanitize et
    }
} else {
    echo 'Belirtilmemiş'; // Eğer kalite belirtilmemişse
}
?>
                                   </span>
                                    <?php } ?>
									
									
									
                            <div class="list-caption Turk-afis-onbilgi">
                                <span class="list-title">
                                    <?php echo $Listing['title'];?>
                                </span>
                                <span class="list-category Turk-afisturu">
                                    <?php echo $Listing['name'];?>
                                </span>
                            </div>							
									
									
									
									</div>
                                </a>

                            </div>
                        </div>
                        <?php } ?>
                    </div>
                    <!-- movies -->
                    <?php echo $Pagination;?>
                    <div class="text-muted text-12">
                        <?php if($TotalRecord == 0) { ?>
                        <?php echo __('No content found');?>
                        <?php } else { ?>
                        <?php echo $TotalRecord;?>
                        <?php echo __('contains content');?>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require PATH . '/theme/view/common/footer.php';?>