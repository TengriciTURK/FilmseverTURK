<div class="modal-content bg-body">
    <div class="modal-body">
        <div class="form-group">
            <label class="custom-label"><?php echo __('Season');?></label>
            <input type="number" name="season" class="form-control" placeholder="<?php echo __('Season');?>" autofocus="true">
        </div>
        <button type="button" class="btn btn-primary btn-lg px-md-5 btn-season"><?php echo __('Create');?></button>
    </div>
</div> 