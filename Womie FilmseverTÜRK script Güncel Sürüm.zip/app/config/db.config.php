<?php
/**
 * Define database config
 */ 

define("DB_HOST","W_HOST"); 
define("DB_NAME","W_NAME"); 
define("DB_USER","W_USER"); 
define("DB_PASS","W_PASS");  