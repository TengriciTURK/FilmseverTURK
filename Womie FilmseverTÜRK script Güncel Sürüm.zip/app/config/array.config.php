<?php
$Qualities = array(
    'TurkSes',
    'TurkYazi',
    'TurkSvY',
    'TurkYapimi'
);
$Reports = array(
      '1'		=> __('The video is not opening'),
      '2'		=> __('Subtitle has character issues'),
      '3'		=> __('Other')
);
$Jquery = array(
      THEME.'/js/jquery.min.js',
      THEME.'/js/bootstrap.bundle.js',
      THEME.'/js/jquery.lazy.js',
      THEME.'/js/jquery.snackbar.js',
      THEME.'/js/jquery.typeahead.js',
      THEME.'/js/jquery.tmpl.js',
      THEME.'/js/jquery.comment.js',
      THEME.'/js/detail.js',
      THEME.'/js/app.js'
);
$JqueryPlayer = array(
      THEME.'/js/plyr.js',
      THEME.'/js/plyr.hls.js',
);