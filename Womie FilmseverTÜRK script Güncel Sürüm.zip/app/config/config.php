<?php 
require_once PATH.'/config/common.config.php'; // Common configuration
require_once PATH.'/config/db.config.php'; // Database configuration 
require_once PATH.'/config/update.php'; // Database configuration 