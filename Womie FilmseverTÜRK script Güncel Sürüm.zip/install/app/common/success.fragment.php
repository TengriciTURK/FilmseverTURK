<div id="success" class="step">
    <span class="success">
        <svg>
            <use xlink:href="../public/assets/img/sprite.svg#check" />
        </svg>
    </span>
    <h1 class="text-white font-weight-bolder">Success!</h1>
    <p>Application has been installed successfully!</p>
    <div class="form-group">
    	<label class="custom-label mb-0">Email</label>
    	<div class="text-white font-weight-bold text-16">admin@admin.com</div>
    </div>
    <div class="form-group">
    	<label class="custom-label mb-0">Password</label>
    	<div class="text-white font-weight-bold text-16">admin</div>
    </div> 
        <a href="<?php echo '../login';?>" class="btn btn-purple">Admin Login</a>
 
</div>