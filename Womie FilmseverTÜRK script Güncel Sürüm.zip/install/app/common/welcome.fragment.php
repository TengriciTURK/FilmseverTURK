        <div id="welcome" class="step">
            <h1 class="text-white font-weight-bolder">Wovie Installation</h1>
            <p>
                Installation process is very easy and it takes less than 2 minutes!
            </p>

            <a href="<?php echo APP.'/install?step=2';?>" class="btn btn-primary next-btn btn-lg px-5">Start Installation</a>
        </div>